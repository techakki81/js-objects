// object at their core are key values pair 

const belgium = {
    name:"Belgium",
    dosesGiven:"1.74M",
    vaccinated:50600,
    population:400000
}

const usa = {
    name:"United States",
    dosesGiven:"174M",
    vaccinated:503600,
    population:4002000
}

const india = {
    name:"India",
    dosesGiven:"61.1M",
    vaccinated:503600,
    population:98600000
}
const arr = [belgium, usa,india]
export default arr
