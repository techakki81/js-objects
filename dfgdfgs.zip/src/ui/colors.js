const colors = {
  $white: "#ffffff",
  $grey01: "#f5f5f7",
  $grey02: "#e8e9ed",
  $grey03: "#dadbe0",
  $grey04: "#bdc2c7",
  $grey05: "#a1a9af",
  $grey06: "#717e85",
  $grey07: "#616f74",
  $grey08: "#4b5559",
  $grey09: "#1f2426",
  $grey10: "#f2f2f2",
  $grey11: "#fcf2fb",

  $green: "#99cc00",
  $green04: "#add633",
  $green03: "#c2e066",
  $green02: "#d6eb99",
  $green01: "#d6eb99",
  $greenHover: "#7caa00",

  $blue: "#003366",
  $blue04: "#335c85",
  $blue03: "#6685a3",
  $blue02: "#99adc2",
  $blue01: "#ccd6e0",

  $home: "#429E34",
  $saveAndInvest: "rgba(144, 63, 159, 1)",
  $saveAndInvestHover: "rgba(169, 19, 108, 1)",
  $saveAndInvestTransparent: "rgba(144, 63, 159, .06)",

  $family: "#F58A1F",
  $health: "#C71780",

  $purple: "#603587",
  $pension: "#1F57A2",

  $firstgraph: "#D971CC",
  $secondgraph: "#add633",
  $thirdgraph: "rgba(169, 19, 108, 1)",
  $fourthgraph: "#F58A1F",
  $fifthgraph: "#1F57A2",

  $mobility: '#00a4d6',
  // $mobility04: '#00c1fc',
  // $mobility03: '#73ddfe',
  // $mobility02: '#b2ecfe',
  // $mobility01: '#ccf3fe',
  $bluelinks: "#007db8",
  $error: "#cc2929",
  $redalerts: "#cc2929",
  $infoalerts: "#de7f0b",
};

export default colors;
