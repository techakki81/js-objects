import { createGlobalStyle } from "styled-components";
import colors from "./colors";
import convertToEm from "./convertToEm";
import bp from "./bp";

const GlobalStyle = createGlobalStyle`
    *{
        box-sizing: border-box;
    }
    body {
        font-family: 'Arial', sans-serif;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        color: ${colors.$grey07};
        font-size: ${convertToEm(15)};
    }
    /* https://stackoverflow.com/questions/16019193/ie-doesnt-accept-font-as-initial-using-important */
    html {
        font-style: normal;
        font-variant: normal;
        font-weight: normal;
        font-stretch: normal;
        font-size: 100%!important; /* Bootstrap fix */
        line-height: normal;
        font-size: initial;
    }

    #compare-funds {
        width: 100%;        
        line-height: normal;
        font-size: 15px;
        box-sizing: border-box;
        display: flex;
        flex-wrap: wrap;
        justify-content:space-between;
        align-items: flex-start;
        background-color: white;
        padding:15px;
        
        *,*:before, *{
            box-sizing: border-box;
        }

        code {
            font-family: source-code-pro, Menlo, Monaco, Consolas, "Courier New",monospace;
        }

        h1, h2, h3, h4, h5, h6{
            font-family: 'Geogrotesque',  sans-serif;
        }

        h2{
            font-weight:400;
            font-size: ${convertToEm(30)} ;
            margin: 5px 0 15px 0;
            ${bp.s`
                font-size: ${convertToEm(21)};
            `}
        }

        ::-webkit-input-placeholder, /* Chrome/Opera/Safari */   
        ::-moz-placeholder,  /* Firefox 19+ */
        :-ms-input-placeholder,  /* IE 10+ */
        :-moz-placeholder { /* Firefox 18- */
            color: #BDC2C7!important;
        }
    }


    /*  MODAL POPUP */
    .ReactModalPortal{
        .ReactModal__Overlay{
            
        }

    }
`;

export default GlobalStyle;
