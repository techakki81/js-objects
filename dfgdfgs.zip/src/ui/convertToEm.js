const convertToEm = (pixels) => {
  const browserDefault = 16;
  return `${pixels / browserDefault}rem`;
};

export default convertToEm;
