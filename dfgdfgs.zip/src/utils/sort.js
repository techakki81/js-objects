const sord = ({faqs,orderBy}=>{



}