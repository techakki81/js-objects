const qnaData = window.qnaData;
export default qnaData;
