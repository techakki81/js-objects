import constants from "./labels";
import qnaData from "./qnaData";
import JsonResp from "./xmlStr";
import labels  from "./labels";
import lang from "./lang";
import search from "./search";

export { constants, qnaData, JsonResp, labels,lang,search};
