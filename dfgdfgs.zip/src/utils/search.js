import { labels } from ".";
const search = (srcText,qnaData,orderBy) => {

    const  searchText = srcText.toLowerCase();

    const chunks = (str, len) =>{
        return str.match(/\S+/g).flatMap((_, i, arr) => 
            arr.slice(i, i + len).map((_, j) => arr.slice(i, i+j+1).join(" "))
        );
    }
    

    let srchArr = [];
    if(!searchText)
    {
      srchArr = [...qnaData];
    }
    else{

      //console.log(chunks(searchText,10))

      let arrPossCombination = chunks(searchText,10).sort((a,b)=> b.length-a.length);       
      let idsAlreadyIn = [];

       arrPossCombination.forEach( srcText =>{
          srchArr.push( ...qnaData.filter( (faq) => {
                if(
                   (  
                     faq.Question.toLowerCase().includes(srcText) || 
                     faq.Answer.toLowerCase().includes(srcText)
                     ) && !idsAlreadyIn.includes(faq.id)){

                  idsAlreadyIn.push(faq.id)
                  return true;             
                }
                else{
                  return false;
                }  
              }))          
            }); 
            
            //console.log(arrPossCombination)
       }

      switch(orderBy)
      {
        
        case labels.sortByRelevenceText.key:         
        
        break;

        case labels.sortByAZText.key: 
          srchArr.sort((a,b)=>{
            if (a.Question > b.Question) {
              return 1;
          }
          if (b.Question > a.Question) {
              return -1;
          }
          return 0;            
          });                
          break;

        case labels.sortByZAText.key:
          
          srchArr.sort((a,b)=>{
            if (a.Question > b.Question) {
              return -1;
          }
          if (b.Question > a.Question) {
              return 1;
          }
          return 0;            
          });                        
          break;

       case labels.sortByNewest.key:          
          srchArr.sort((a,b)=>{

            const dtA = new Date(a.PublicationDate);
            const dtB = new Date(b.PublicationDate);      

           if(dtA>dtB){                      
            return -1;
           }
            else{
              return 1;
            }
          });           
          break;
          case labels.sortByOldest.key:          
          srchArr.sort((a,b)=>{

          const dtA = new Date(a.PublicationDate);
          const dtB = new Date(b.PublicationDate);
            
           if(dtB>dtA){                      
            return -1;
           }
            else{
              return 1;
            }
          });           
          break;
        default:          
          break;
      }
      return srchArr;
    };
export default search;