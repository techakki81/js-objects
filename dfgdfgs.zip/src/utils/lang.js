
const lang = window.qnaLang?window.qnaLang.toLowerCase():window.lang.toLowerCase();
//console.log(window.qnaLang)
//console.log(lang)
export default lang;

