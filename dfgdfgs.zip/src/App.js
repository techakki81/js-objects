import React, { useState,useRef,useEffect } from "react";
import { qnaData, labels,lang,search } from "./utils";
import { FaqPanel, Filters,DrpDown,Burger} from "./components";
import queryString from "query-string";
import GlobalStyle from "./ui/globalStyle"

// Use this to test
// http://localhost:3000/#Default=%7B%22k%22%3A%22test%20trst%22%2C%22r%22%3A%5B%5D%7D


function App() {
 
  let searchedText = "";
  
  try{
    searchedText = JSON.parse(
       queryString.parse(window.location.hash)?.Default
     )?.k; 
  }
  catch{}

  
const ref = useRef(searchedText)
const searchText = ref.current
//console.log(searchText)
  // one less than how many you want 
 let faqsPerPage = 30; 
 const defaultSort = searchText?labels.sortByRelevenceText.key:labels.sortByNewest.key; 
 const [sortOrder, setSortOrder] = useState(defaultSort);
 const [currPage, setCurrPage] = useState( 1 );
 let searchedFaqs = search(searchText,qnaData,sortOrder);
 const [pageFaqs, setFaqs] = useState( searchedFaqs.slice(0,faqsPerPage)|| null); 


 // pagination counts
 let maxPagination = Math.ceil(searchedFaqs.length/faqsPerPage);
 let paginationArr = [];
 for(let i = 1; i <= maxPagination; i++){ 
  paginationArr.push(i);
  } 

  const handleFilterClick = (e) => {
    e.preventDefault();
    let filterText = e.target.getAttribute("data-aglivalue");
    let category = e.target.getAttribute("data-aglicategory");
    let matchingFaqs = [];   

    // if the filter is ALL , then get all the
    if (filterText === labels.allFilter) {
      matchingFaqs = search(searchText,qnaData,sortOrder);
    } else {
      let srchFaqs = search(searchText,qnaData,sortOrder);
      // get the corressponding property and then filter on it
      srchFaqs.forEach((faq) => {
        let property = faq[category];
        property.forEach((singleVal) => {
          if (singleVal === filterText) matchingFaqs.push(faq);
        });
      });
    }
    setFaqs(matchingFaqs.slice(0,faqsPerPage));

    // change the css of the li clicked
  //  console.log(e.target.parentElement)
    if( filterText !== labels.allFilter){
      e.target.style="font-weight:700";
    }    else 
     {
      e.target.parentElement.children.forEach(c=>{c.style="font-weight:400;"})     
     }
  };

  const handleDropDownClick = (e)=>{
    e.preventDefault();    
    setFaqs(search(searchText,qnaData,e.target.value).slice(0,faqsPerPage));
    setSortOrder(e.target.value); 
  }

  const handlePaginationClick = (e)=>{ 
    
    let index = e;    
    if(e === 0 ){
      index = 1;
    }
    else if (e === maxPagination || e === maxPagination+1){
      index = maxPagination;
    }
      
    setCurrPage(index);
    setFaqs(search(searchText,qnaData,sortOrder).slice(index,index+faqsPerPage));   
  }

  const [width, setWidth]   = useState(window.innerWidth);
  const updateDimensions = () => {
    setWidth(window.innerWidth);
  }

useEffect(() => {
    window.addEventListener("resize", updateDimensions);
    return () => window.removeEventListener("resize", updateDimensions);
}, []);

const [dispFltSmall, setdispFltSmall] = useState(false);

 const onBurgerClick =() =>{
  setdispFltSmall(!dispFltSmall)
 }

if (searchedFaqs.length === 0) return <div>{labels.noSearchFoundText[lang]}</div>;
  else
    return (
      <div id="compare-funds"> 

      {width<=767 && <Burger onbugclick ={onBurgerClick}></Burger>}
      
      <GlobalStyle />          
      
        <DrpDown onDrpChange={handleDropDownClick} windowWidth={width} defaultValue={defaultSort}></DrpDown>
        <Filters onFilterClick={handleFilterClick} faqs={searchedFaqs}  displayFilters={dispFltSmall}></Filters>
        <FaqPanel searchedFaqs={searchedFaqs} faqList={pageFaqs} currentpage={currPage} paginationarr={paginationArr} handlerpaginationclick={handlePaginationClick} 
        displayFilters={dispFltSmall}></FaqPanel>
        
        {/* <Pagination currentval={currPage} paginationArr = {paginationArr} onClick={handlePaginationClick} ></Pagination>    */}
        {/* <a target="_blank" href={labels.hrefTrmsUse[lang]}>{labels.termsOfUse[lang]}</a> */}
      </div>
    );
}
export default App;
