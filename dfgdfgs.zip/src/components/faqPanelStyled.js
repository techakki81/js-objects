import Styled from "styled-components";
import { colors, bp, convertToEm } from "../ui";

const FaqPanelStyled = Styled.aside`
    width: calc(100% - 265px);
    ${bp.s`
        width: ${props=>props.displayFilters?"18%":"100%"};
    `}
    .filter-item{
        border-bottom: 1px solid ${colors.$grey03}; 
        background-color: #fff;
        padding: 0 0px 0 0px;

        &:last-child{
            border-bottom: none;
        }
        h6{
            font-family: "Geogrotesque-Medium", sans-serif;
           
        }

        div, p{
            font-size: ${convertToEm(14)};
            line-height: 1.6;
            colors: ${colors.$grey06};
            font-family: "Open_Sans", sans-serif;
        }
    }
`;

export default FaqPanelStyled;