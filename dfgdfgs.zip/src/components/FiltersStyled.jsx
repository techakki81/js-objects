import Styled from "styled-components";
import { colors, convertToEm, bp } from "../ui";



const FiltersStyled = Styled.aside`
    width: 235px;
    padding:0px 15px 15px 15px;
    overflow: hidden;   
    background-color: #fafafa;

    ${bp.s`
      display:${props=>props.displayFilters?"block":"none"};
      width: ${props=>props.displayFilters?"80%":"100%"};;
      padding: 15px;    
      padding-left: 22px;
    `}


    h5{
      margin: 0 0 15px;
      font-size: ${convertToEm(17)};
      font-weight: 400;

      ${bp.s`
        display: none; 
      `}
    }

    .panel{
      ${bp.s`
        display: none;
        margin: 0;
        &.open{
          display: block;
          border: 1px solid ${colors.$grey03};
          padding: 0 15px 15px 15px;
          margin: 0 0 15px 0;
        }
      `}
    }

    button.h5{
      display: none; 
      position: relative;
      z-index: 2;

      ${bp.s`       
        display: block;
        position: relative;
        width: 100%;
        color: white;
        padding: 9px 15px;
        margin: 0 0 15px 0;
        border: none;
        background-color:${colors.$grey07};
        border-radius: 3px;
        text-align: left; 
        text-transform: uppercase;
        font-family: 'Geogrotesque-Semibold';
        font-weight:600;
        outline: 0;

        svg {
          position: absolute;
          right: 11px;
          top: 9px;
        }
      `}
    }

    /* green button under filters for mobile
    
    .mobile-cont{
      ${bp.s`
        border:1px solid $grey02;
        padding: 0 15px;
      `}
      .green-button{
        width: 100%;
        display: none;
        margin-bottom:15px;
        ${bp.s`
        display:block;
      `}
      }
    } */

    .filter-item{
      position:relative;        
      border-bottom: 1px solid ${colors.$grey03};
      padding: 10px 0; 
      
      &:last-child{
        border-bottom: none;
      }
          
      h6{
        padding: 5px 0 0px 0;
        margin: 0;        
        font-weight:600;
        line-height: 18px; 
      }

      ${bp.s`
         &:first-child{
          border-top: none;
        }
        &:last-child{
          border-bottom: none;
        }
      `}
    }

    ul.collapsable{
      padding-left:0;
      margin:  0;
      overflow: hidden;
      color: ${colors.$grey05};
      font-family: "Open_Sans", sans-serif;
      /* transition: 0.2s ease-in-out all;
      height: auto; */
      p{
        margin:0 0 10px 0;
        font-size: ${convertToEm(16)};

      }
      li{
        list-style: none;
        padding: 0px 0 0px 15px;
        font-size: ${convertToEm(14)}; 
        line-height: 1.5;

        label{
          display: inline-block;
          padding-left:8px;
          vertical-align: top;
        }

        [data-all="true"] + label {
          font-weight:600; 
        }

        &:first-child{
          padding : 10px 0 10px 0;
        }
     }

     a{
       text-align: right;
       display: block;
       padding: 10px 5px;
       color: ${colors.$mobility};
       text-decoration:none;
     
       &:hover, &:visited{
        color: ${colors.$bluelink};
       }
       img{
          width: 5px;
          transform:rotate(90deg);
          transform-origin: center;
          display: inline-block;
          margin-left: 8px;   

          &.open{
            transform: rotate(270deg);
            margin-bottom: 0px;
          }
       }
     }
  }
`;

export default FiltersStyled;
