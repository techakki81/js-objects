import React, {useState} from "react";
import { useCookies } from 'react-cookie';
import Modal from 'react-modal';
import { labels, lang } from "../utils";
import CollapsablePanel from './CollapsablePanel';
import FaqPanelStyled from "./faqPanelStyled";
import Styled from  'styled-components';
import { colors, convertToEm } from "../ui";
import Pagination  from "./Pagination";
Modal.defaultStyles.overlay.backgroundColor = 'rgba(0,0,0,.5)';
Modal.defaultStyles.overlay.zIndex = '1033';

const  envelop  =  "/Documents/qna/img/icon-mail.svg";
const  crossClose  =  "/Documents/qna/img/cross.png"

const Hyp = Styled.a`
  color: ${colors.$bluelinks}!important;
`

const AssTo =  Styled.div`
  padding: 20px 0 20px 0;
  a{
    color: ${colors.$grey07};
    text-decoration: none;
     &:hover, &:visited{
      color: ${colors.$bluelinks};
    }
  }
  
  &:before{
    content: url(${envelop});
    display: inline-block;
    margin-right: 7px;
    vertical-align: middle;
  }
`;

const PopupTitle = Styled.div`
  display:flex;
  justify-content: space-between;
  align-items: flex-start;
  border-bottom: 1px solid ${colors.$grey02};
  h3{
    padding: 11px 0;
    text-align: center;
    width: calc(100% - 40px);
    margin:0;
    font-weight: 400;
    font-family: geogrotesque_medium , sans-serif;
    font-size: 25px;
    color: ${colors.$grey05};
    line-height: 1.4;
  }
  button{
    width: 55px;
    height: 55px;
    min-width: initial;
    box-sizing: border-box;
    background: url(${crossClose}) no-repeat center;
    background-color: white;
    background-size: 15px 15px;
    border:none;    
  }  
`;
const ContentH = Styled.div`
  padding: 15px;
  font-family: "OpenSans", sans-serif;
  font-size: ${convertToEm(15)};
  line-height: 1.6;
  a{
    text-decoration: none;
  }
  p{
    margin: 0 0 0px 0;
  }
`;


const ContentCheckbox = Styled.div`
    padding: 15px 15px 30px 15px;
    font-family: "OpenSans", sans-serif;
    font-size:  ${convertToEm(15)};
    line-height: 1.6;
    input{
      margin: 0 10px 0  0  !important;
    }
    label{
      font-size:  ${convertToEm(15)};
    }
`;

const ButtonOk = Styled.button`
    width: calc(100% - 30px);
    box-sizing:border-box;
    padding: 15px;
    background-color: ${colors.$green};    
    border: none;
    display: block;
    margin: 0 auto 30px auto;
    color: #fff!important;
    text-decoration: none!important;
    font-family: geogrotesque_medium,"Trebuchet MS",sans-serif;
    font-size: 16px;
    &:hover{
      background-color: ${colors.$greenHover};
    }
`;

const FaqPanel = ({ searchedFaqs,faqList, currentpage, paginationarr, handlerpaginationclick,displayFilters=false }) => {
  
  const cookieName = 'qnaCookie';
  const qusText = labels.emailBodyText[lang];
  const style = {
    content: {
      top: '50%',
      right: 'initial',
      left: '50%',
      bottom: "initial",
      transform: 'translate(-50%, -50%)',
      height: 'auto', 
      width: '85%',
      maxWidth: '600px',
      boxShadow: '0 5px 15px rgba(0,0,0,.5)',
      padding: ' 0'
    }
  }
  
  const [showPopup, setshowPopup] = useState(false)
  const [faq, setFaq] = useState('')
  const [cookies, setCookie] = useCookies([cookieName])

  //console.log(cookies)

const afterOpenModal = ()=>{
  console.log("After Open Model")
}
const onChkBoxClick = (e)=>{
   // if true then set the cookie
    if(e.target.checked)
      setCookie(cookieName,true)
    else
      setCookie(cookieName,false)
   // if false se the cookie
}

const closePopup = ()=>{
  // open outloo 
  window.location.href = `mailto: ${faq.AssignedTo.email}?subject=${faq.id} –  ${faq.AssignedTo.Name} – ${encodeURIComponent('Q&A')} AG Business Academy Inside &body=${qusText +encodeURIComponent(faq.Question)}`
  setshowPopup(false)
}
const closeModal = ()=>{ 
  closePopup();
}
const setCurrentFaq =(e,faq)=>{
  e.preventDefault()
  if(cookies?.qnaCookie){    
      setshowPopup(false)
      window.location.href = `mailto: ${faq.AssignedTo.email}?subject=${faq.id} – ${faq.AssignedTo.Name} – ${encodeURIComponent('Q&A')} AG Business Academy Inside &body=${qusText+ encodeURIComponent(faq.Question)}`      
     // setshowPopup(true);  
  }
  else
  {
     setshowPopup(true);      
  }  
  setFaq(faq)
}
    

 return (
  <FaqPanelStyled className="faq-panel" displayFilters={displayFilters}>
     <Modal
          style={style} 
          isOpen= {showPopup}
          onAfterOpen={afterOpenModal}
          onRequestClose={closeModal}          
          contentLabel="Modal"
          ariaHideApp={false}
        >
           <PopupTitle className="popup-title"> 
              <h3>{labels.popupHeader[lang]}</h3>
              <button onClick={closePopup}></button>
              {/* <button onClick={closePopup}>{labels.btnPopUp[lang]}</button> */}
            </PopupTitle>
            <ContentH>
              {labels.popupFirstLine[lang]} 
              <p>
               {labels.popupSecondLine[lang]}   
               <strong>
                {labels.popupAGBusinessAcademy[lang]}
               </strong>
              </p>
            </ContentH>
            {/* <ContentH>{labels.popupSecondLine[lang]}</ContentH> */}
            <ContentH>
                <p>{labels.popupThirdLine[lang]}</p>
                <p>{labels.popupFourthLine[lang]} <Hyp href="mailto:helpbrokers.broker@aginsurance.be">{labels.popupEmail[lang]}</Hyp></p>
                
            </ContentH>
            <ContentCheckbox>           
              <input type="checkbox" id="chkBox" name="DontShowAgain" value="dontshowAgain" onClick={onChkBoxClick}/>
              <label htmlFor="DontShowAgain"> {labels.popupChkBox[lang]}</label>
            </ContentCheckbox>
            <ButtonOk onClick={closePopup}>{labels.btnTextOk[lang]}  </ButtonOk>
     </Modal>

      {faqList.map((faq, index) => (
        <CollapsablePanel key={index} name={faq.id+":"+faq.Question} widthPercent="100" className="test-case">
             <div dangerouslySetInnerHTML={{__html:faq.Answer}}/>  
             <AssTo> 
              {labels.contactPerson[lang]}{lang==="fr"?<span> </span>:""}: <span> </span>
              <a href="/" onClick={(e)=>setCurrentFaq(e,faq)}> 
                <strong>{faq.AssignedTo.Name}</strong> 
              </a>  
              </AssTo>
             <div> {labels.publicateDateText[lang]}{lang==="fr"?<span> </span>:""}: <strong>{faq.PublicationDate}</strong></div> 
         </CollapsablePanel>  
        // <CollapsablePanel key={index} name={ faq.id+":"+faq.Question+":"+faq.PublicationDate}  className="test-case">
        //     {faq.Answer} 
        // </CollapsablePanel>        
      ))}
        <Pagination searchedFaqsCount ={searchedFaqs.length} currentval={currentpage} paginationArr = {paginationarr} onClick={handlerpaginationclick}></Pagination>
    </FaqPanelStyled>
  )
}
export default FaqPanel


