import React, { useState, useRef } from "react";
import styled, { css } from "styled-components";
import { convertToEm,colors} from "../ui";

const Collapser = styled.ul`
  /* transition: height 0.3s ease-out; */
  height: auto;
  overflow: hidden;
  padding-left: 0;
  margin: 0 0 30px 0;
  ${({ collapsed }) =>
    collapsed &&
    css`
      height: 0;
      margin: 0;
    `}
`;

const Toggler = styled.button`
  vertical-align: middle;
  appearance: none;
  transform: rotate(180deg);
  border: none;
  background-color: transparent;
  height: 30px;
  width: 30px;
  outline: 0;
  margin-left: 10px;
  min-width: initial;
  min-width: auto;
  ${({ collapsed }) =>
    collapsed &&
    css`
      transform: rotate(90deg);
      top: 11px;
    `};

  img {
    vertical-align: middle;
    transform: rotate(-90deg);
  }
`;

const Title = styled.h6`
  cursor: pointer;
  font-size: ${convertToEm(18)};
  font-weight: 400;
  margin: 0;
  padding: 28px 0;
  line-height: 25px;
  color: ${colors.$grey07};
  span{
    display: inline-block;
    width: calc(${({widthPercent})=>widthPercent + "%" } - 40px);   
    vertical-align: middle; 
    ${props => props.filterSection && css`
    color: #46525b;
    font-size: 18px!important;
    font-family: geogrotesque_medium,"Trebuchet MS",sans-serif;
  `}
    }
`;

const CollapsablePanel = ({name,widthPercent="100", initialCollapse=true, filterSection=false, children}) => {
  let arrowUp ="/Documents/qna/img/arrow-r-small.svg"
  const [collapse, setCollapse] = useState(initialCollapse);
  const listRef = useRef(null);
 // const { name } = props;
  
 //console.log(widthPercent);

  function toggleSlide(e) {
    e.preventDefault();
    setCollapse(!collapse);
  }

  return (
    <div className="filter-item">
      <Title filterSection={filterSection} onClick={(e) => toggleSlide(e)} widthPercent={widthPercent}>
        <span>{name}</span>
        <Toggler collapsed={collapse}>
          <img src={arrowUp} alt="button - show/hide filters" />
        </Toggler>
      </Title>
      <Collapser ref={listRef} className="collapsable" collapsed={collapse}>
        {children}
      </Collapser>
    </div>
  );
};

export default CollapsablePanel;
