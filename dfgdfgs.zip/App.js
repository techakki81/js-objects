import React, { useState } from "react";
import { qnaData, labels,lang,search } from "./utils";
import { FaqPanel, Filters } from "./components";
import queryString from "query-string";

// Use this to test
// http://localhost:3000/#Default=%7B%22k%22%3A%22test%20trst%22%2C%22r%22%3A%5B%5D%7D


function App() {

  let searchText = JSON.parse(
       queryString.parse(window.location.hash)?.Default
     )?.k; 


  const [filteredFaq, setFilteredFaq] = useState(search(searchText,qnaData) || null);
  
  const handleFilterClick = (e) => {
    let filterText = e.target.getAttribute("data-aglivalue");
    let category = e.target.getAttribute("data-aglicategory");
    let matchingFaqs = [];

    // if the filter is ALL , then get all the
    if (filterText === labels.allFilter) {
      matchingFaqs = search(searchText,qnaData);
    } else {
      // get the corressponding property and then filter on itnp
      filteredFaq.forEach((faq) => {
        let property = faq[category];
        property.forEach((singleVal) => {
          if (singleVal === filterText) matchingFaqs.push(faq);
        });
      });
    }
    setFilteredFaq(matchingFaqs);
  };

if (filteredFaq.length == 0) return <div>{labels.noSearchFoundText[lang.toLowerCase()]}</div>;
  else
    return (
      <div id="compare-funds">
        <FaqPanel faqList={filteredFaq}></FaqPanel>
        <Filters onFilterClick={handleFilterClick} faqs={filteredFaq}></Filters>
      </div>
    );
}

export default App;
