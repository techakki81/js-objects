const labels= window.qnaLabels;
export default labels;

// const labels = {
//   branch: {
//     nl: "Takken",
//     fr: "Branches",
//   },
//   groupCible: {
//     nl: "Doelgroepen",
//     fr: "Group Cible",
//   },
//   groupDeProduit: {
//     nl: "Productgroepen",
//     fr: "Group De Produit",
//   },
//   product: {
//     nl: "Product",
//     fr: "Produit",
//   },
//   tagsLibre: {
//     nl: "Vrije Tags",
//     fr: "Tags Libre",
//   },
//   allText: {
//     nl: "Alle",
//     fr: "Tout",
//   },  
//   noSearchFoundText: {
//     nl: "No search result found",
//     fr: "No search result found",
//   },    
//  sortByRelevenceText: {
//     nl: "Relevantste eerst",
//     fr: "Par pertinence",
//     key:"SORT_RELEVENCE"
//   },     
//  sortByAZText: {
//     nl: "A - Z",
//     fr: "A - Z",
//     key:"SORT_AZ"
//   },
//   sortByZAText: {
//     nl: "Z - A",
//     fr: "Z - A",
//     key:"SORT_ZA"
//   },
//   sortByNewest: {
//     nl: "Nieuwste eerst",
//     fr: "Du plus récent au plus ancien",
//     key:"SORT_DATE_NEWEST"
//   },  
//   publicateDateText: {
//     nl: "Publicatiedatum",
//     fr: "Date de publication",   
//   }, 
//   showMore:{
//     nl:"Toon meer",
//     fr:"Montrer plus"
//   }, 
//   showLess:{
//     nl:"Toon minder",
//     fr:"Montrer moins"
//   },  
//   termsOfUse:{
//     nl:"Terms of use",
//     fr:"Terms of use"
//   },  
//   hrefTrmsUse:{
//     nl:"https://corporate.common.intranet/nl/paginas/terms-of-use.aspx",
//     fr:"https://corporate.common.intranet/fr/pages/terms-of-use.aspx"
//   },    
//   contactPerson:{
//     nl:"Uw contactpersoon",
//     fr:"Votre contact"
//   },  
//   popupHeader:{
//     nl:"Q&A AG Business Academy",
//     fr:"Q&A AG Business Academy"
//   },  
//   popupFirstLine:{
//     nl:"Zo meteen gaat u door naar uw mailbox.",
//     fr:"Vous allez être redirigé vers votre boite e-mail."    
//   },
//   popupSecondLine:{
//     nl:"Uw vraag wordt verstuurd naar de ",
//     fr:"Votre question sera envoyée chez "    
//   },
//   popupThirdLine:{
//     nl:"Hebt u een technisch probleem?",
//     fr:"Un souci technique ? "    
//   },
//   popupFourthLine:{
//     nl:"Neem dan contact op met de helpdesk via 02 664 17 20 - ",
//     fr:"Contactez alors le helpdesk au 02 664 17 20 - "    
//   },  
//   popupEmail:{
//     fr:"helpbrokers.broker@aginsurance.be",
//     nl: "helpbrokers.broker@aginsurance.be"
//   },
//   popupAGBusinessAcademy:{
//     fr:"AG Business Academy",
//     nl: "AG Business Academy"
//   },  
//   btnTextOk:{
//     nl:"OK",
//     fr:"OK"
//   },
//   popupText:{
//     nl:"The mail will be send to AG Business School's general mailbox and not to the user",
//     fr:"The mail will be send to AG Business School's general mailbox and not to the user"
//   },
//   popupChkBox:{
//     nl:"Niet meer weergeven",
//     fr:"Ne plus afficher"
//   },
//   btnPopUp:{
//     nl:"Fermer",
//     fr:"Fermer"
//   },  
//   sortText:{
//     nl:"Order : ",
//     fr:"Ordre : "
//   },
//   totalResultCount:(count,lang)=>{
//     return (lang=="nl"? `Ongeveer ${count} resultaten`:`Environ  ${count} résultats`)    
//   },
//  emailBodyText:{
//    nl:"Vraag : ",
//    fr:"Question par rapport à : "   
//  },
//   emailAddressTrainer:"traininginsurances.broker@aginsurance.be" ,
//   emailHelp:"helpbrokers.broker@aginsurance.be",
//   allFilter: "ALL",
//   colbranch: "Branche",
//   colgroupCible: "GroupCible",
//   colgroupeDeProduit: "GroupeDeProduit",
//   colproduct: "Produit",
//   coltagsLibre: "TagsLibres"
  
// };



