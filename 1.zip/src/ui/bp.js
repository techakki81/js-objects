// this is the breakpoint function to use media queries
// source: https://tobbelindstrom.com/blog/how-to-create-a-breakpoint-mixin-with-styled-components/

/*
  use in component:
   ${bp.s`
		background-color: aqua;
	`}

  ${bp.m`
		background-color: red;
	`}
*/

import { css } from "styled-components";
import breakpoints from "./breakpoints";

const bp = Object.keys(breakpoints).reduce((accumulator, label) => {
  accumulator[label] = (...args) => css`
    @media (max-width: ${breakpoints[label]}) {
      ${css(...args)};
    }
  `;
  return accumulator;
}, {});

export default bp;
