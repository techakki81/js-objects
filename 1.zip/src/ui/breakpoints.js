// max breakpoints

const breakpoints = {
  s: "767px",
  m: "991px",
  // lg: `${Infinity}px`
  numbers: {
    s: 767,
    m: 991,
  },
};

export default breakpoints;
