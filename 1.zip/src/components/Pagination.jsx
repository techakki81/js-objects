import React from 'react';
import styled from "styled-components";
import { labels, lang } from "../utils";

const UL=  styled.ul`
    margin: 0!important;
    /* border: 2px solid #ededef; */
     /* border-top: 1px solid #ededef; */
    position: relative;
    /* height: 70px; */
    line-height: 20px;
    font-family: "Open Sans", sans-serif;
    text-align: center;      
    list-style-type: none;  
    box-sizing: content-box;
    display: block;  
    padding: 10px 0 10px 0;   
`;

const LI=  styled.li`
    display: inline-block;
`;

const Anchor = styled.a`
    color: ${({selected})=> selected ? "#9c0!important;": "#46525b!important;" };
    font-family: "Open Sans", sans-serif;
    font-size: 15px;
    font-weight: 400;
    text-decoration: none;
    margin: 0px;
    padding: 1px 7px 4px 8px; 
    display: inline-block;
    padding: 15px 8px;
`;

const ArrowLeft = styled.img`
    transform: rotate(-180deg);
    vertical-align: middle;
    display: inline-block;
    padding: 10px 10px;
    position: absolute;
    top: 19px;
    left:0;
`;

const ArrowRight = styled.img`    
    transform: rotate(0deg);
    vertical-align: middle;
    display: inline-block;
    padding: 10px 10px;
    position: absolute;
    top: 19px;
    right: 0;
`;

const PaginationStyled = styled.aside`
    width: 100%;
    text-align: center;
    padding: 15px 0 30px 0;
`;

// const TermsLink = styled.a`
//     text-decoration:none;
//         padding: 15px 0;
//         display: inline-block;
// `;

const  Pagination = ({searchedFaqsCount,paginationArr, onClick, currentval}) => {   
const arrowUp = "/Documents/qna/img/arrow-r-small.svg";

let totalResultCount =   `${labels.totalResultCounPrefix[lang] +  searchedFaqsCount + labels.totalResultCounSuffix[lang] }` 

    return (            

        <PaginationStyled className="pagination">          
           <UL>
           <ArrowLeft src={arrowUp} onClick={()=>onClick(currentval-1)} />
            {
              paginationArr.map( (index)=>{
                 return (
                        <LI key={index}  value={index}>
                            <Anchor 
                                    selected = {currentval=== index?true:false}
                                    href="#" 
                                    onClick={()=>onClick(index)}>
                                {index}                            
                            </Anchor>                                                        
                        </LI>                       
                        );   
                    })
            }
              <ArrowRight src={arrowUp} onClick={()=>onClick(currentval+1)}/>
           </UL>
           <div>
            <span>{totalResultCount}</span>
           {/* <TermsLink target="_blank" href={labels.hrefTrmsUse[lang]}>{labels.termsOfUse[lang]}</TermsLink> */}
           </div>
           

        </PaginationStyled> 
         
    )
}
export default Pagination;
