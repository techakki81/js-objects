import React from 'react';
import {labels, lang} from '../utils';
import Styled from "styled-components";
import { colors, convertToEm} from "../ui";

const DropDownStyled = Styled.div`
    width: ${({windowWidth}) => windowWidth < 767 ?"80%;":"100%;"}; 
    text-align: right;
    padding: 20px 0;
    select{
        // padding: 10px;
        border: 1px solid ${colors.$grey03};
        font-size: ${convertToEm(15)};
    }
`;


const DrpDown =({onDrpChange,windowWidth, defaultValue})=> {

    return (
             
        <DropDownStyled className="sort-options-dropdown" windowWidth={windowWidth}>
             <span> {labels.sortText[lang] }</span>
            <select name="sortOptions" id="sortOptions" onChange={onDrpChange} defaultValue={defaultValue} >
                <option value={labels.sortByRelevenceText.key}>{labels.sortByRelevenceText[lang]}</option>
                <option value={labels.sortByAZText.key}>{labels.sortByAZText[lang]}</option>
                <option value={labels.sortByZAText.key}>{labels.sortByZAText[lang]}</option>
                <option value={labels.sortByNewest.key}>{labels.sortByNewest[lang]}</option>
                <option value={labels.sortByOldest.key}>{labels.sortByOldest[lang]}</option>
            </select>            
        </DropDownStyled>
       
    );
}

export default DrpDown;


