import React,{useState} from 'react';
import styled from "styled-components";

const BurgerStyle = styled.a`
 i{
    padding: 24px 16px 23px 21px;
    color: #9c0;
    background-color: #fff;
    font-size: 20px;
    display: inline-block;
 }
`
const Burger = ({onbugclick})=>{

   let opnBtn ="/Documents/Qna/Img/openFilter.png"
   let closedBtn ="/Documents/Qna/Img/closeFilter.png"

    const[imgsrc,setImg]= useState(opnBtn)  

const btnBrugerClick =(e)=>{
    if(imgsrc===opnBtn)
       setImg(closedBtn)
     else
        setImg(opnBtn)

     onbugclick(e)
}
return(
    <BurgerStyle onClick={(e)=>btnBrugerClick(e)}>
    	    <img alt="menu" src= {imgsrc}></img>
    </BurgerStyle>
    )
}

export default Burger;

 