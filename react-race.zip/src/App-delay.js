import './App.css';
import {useState,useEffect} from 'react'

function App() {

  const [country, setCountry] = useState('N.A.')
  const [capital, setCapital] = useState('')


useEffect(() => {      

  const ctrl = new AbortController(); 
  const load = async() =>{
     try
       {
         //debugger
          const response = await fetch(`https://restcountries.eu/rest/v2/capital/${capital}`,
          {signal:ctrl.signal})
          const jsonObj = await response.json()
          setTimeout( ()=> {setCountry(jsonObj[0].name)} , Math.random()*10000)    
       }
    catch(err)
    {
      console.log(err)
    }  
 }
  load();

  return () =>{              
              ctrl.abort() 
            };

}, [capital])


  return (
    <div>
       <button  onClick={()=>setCapital("Berlin")}  >Berlin</button>      
       <button  onClick={()=>setCapital("Paris")}  >Paris</button>      
       <button  onClick={()=>setCapital("Madrid")}  >Madrid</button>   
       <div> 
         {country}
      </div>  
    </div>
  );
}

export default App;