import './App.css';
import {useState,useEffect} from 'react'

function App() {

  const [country, setCountry] = useState('N.A.')
  const [capital, setCapital] = useState('')
 
  
useEffect(() => {   
  
 let ctrl = new AbortController()

 const load = async() =>{
  try
    {
      //debugger
       const url = `http://slowwly.robertomurray.co.uk/delay/${Math.random()*10000}/url/https://restcountries.eu/rest/v2/capital/${capital}`
       console.log(url)
       const response = await fetch(url,{signal:ctrl.signal})
       const jsonObj = await response.json()
       setTimeout( ()=> {setCountry(jsonObj[0].name)} , Math.random()*10000)    
    }
 catch(err)
 {
   console.log(err)
 }  
}
load();
  

return  () => {
  let i = 23
  console.log(`call aborted` , ctrl.capital)
  ctrl.abort()
} 



}, [capital] )

  
  return (
    <div>
       <button  onClick={()=>setCapital("Berlin")}  >Berlin</button>      
       <button  onClick={()=>setCapital("Paris")}  >Paris</button>      
       <button  onClick={()=>setCapital("Madrid")}  >Madrid</button>   
       <div> 
         {country}
      </div>  
    </div>
  );
}

export default App;
